# Disclaimer Vertrekdetectie

Vertrekdetectie is enkel en alleen toegevoegd ten behoeve van het testen van DONNA.
De EDL wordt getest in het Railcenter zonder vertrekdetectie.
De EDL wordt in dienst gesteld zonder vertrekdetectie.

T.b.v. de vraag vanuit ProRail om een IMX van de EDL met Vertrekdetectie te leveren is de volgende bewerking uitgevoerd:
- Er is een kopie gemaakt van de levering (aan o.a. Hitachi) van 2025 02 21.
- Voor ovw 22.3 is een kind object DepartureDetectionPoint toegevoegd. De locatie van het DepartureDetectionPoint is gezet op de locatie van het VD punt.
- Het ontwerp van de vertrekdetectie is conform OVS60040-2 versie 004.
- Het ontwerp van de vertrekdetectie is conform RVTO versie 3.0.
- Deze IMX levering is niet intern of extern gecontroleerd.
