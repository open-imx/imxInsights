# XSD errors
Schema: XMLSchema10(name='IMSpoor-SignalingDesign.xsd', namespace='http://www.prorail.nl/IMSpoor')
/SignalingDesign/Ertms/ErtmsSignals/ErtmsSignal[2]/TransitionSignal/L2ExitTransition[1]/MovementAuthority : The content of element '{http://www.prorail.nl/IMSpoor}MovementAuthority' is not complete. Tag '{http://www.prorail.nl/IMSpoor}Packet_80' expected.
/SignalingDesign/Ertms/ErtmsSignals/ErtmsSignal[2]/TransitionSignal/L2ExitTransition[2]/MovementAuthority : The content of element '{http://www.prorail.nl/IMSpoor}MovementAuthority' is not complete. Tag '{http://www.prorail.nl/IMSpoor}Packet_80' expected.
/SignalingDesign/Ertms/ErtmsSignals/ErtmsSignal[2]/TransitionSignal/L2ExitTransition[3]/MovementAuthority : The content of element '{http://www.prorail.nl/IMSpoor}MovementAuthority' is not complete. Tag '{http://www.prorail.nl/IMSpoor}Packet_80' expected.
